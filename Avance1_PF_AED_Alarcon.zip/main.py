# main.py
import tkinter as tk
from tkinter import ttk, messagebox
import threading
from player import MusicPlayer
from songs import songs

def reproducir():
    seleccion = lista_canciones.curselection()
    if not seleccion:
        messagebox.showwarning("Aviso", "Selecciona una canción")
        return
    index = seleccion[0]
    cancion = songs[index]
    threading.Thread(target=player.play, args=(cancion["archivo"],)).start()

def pausar():
    player.pause()

def continuar():
    player.unpause()

def detener():
    player.stop()

# Crear ventana principal
ventana = tk.Tk()
ventana.title("Reproductor de Twice 🎶")

# Lista de canciones
lista_canciones = tk.Listbox(ventana, width=40, height=10)
for s in songs:
    lista_canciones.insert(tk.END, s["titulo"])
lista_canciones.pack(pady=10)

# Botones
frame_botones = tk.Frame(ventana)
frame_botones.pack()

btn_play = tk.Button(frame_botones, text="▶ Play", command=reproducir)
btn_pause = tk.Button(frame_botones, text="⏸ Pause", command=pausar)
btn_unpause = tk.Button(frame_botones, text="⏯ Continue", command=continuar)
btn_stop = tk.Button(frame_botones, text="⏹ Stop", command=detener)

btn_play.grid(row=0, column=0, padx=5)
btn_pause.grid(row=0, column=1, padx=5)
btn_unpause.grid(row=0, column=2, padx=5)
btn_stop.grid(row=0, column=3, padx=5)

# Inicializar reproductor
player = MusicPlayer()

ventana.mainloop()