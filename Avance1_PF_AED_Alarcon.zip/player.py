# player.py
import pygame

class MusicPlayer:
    def __init__(self):
        pygame.mixer.init()  # Inicializa el mixer de audio
        self.current_song = None

    def play(self, archivo):
        pygame.mixer.music.load(archivo)
        pygame.mixer.music.play()
        self.current_song = archivo

    def pause(self):
        pygame.mixer.music.pause()

    def unpause(self):
        pygame.mixer.music.unpause()

    def stop(self):
        pygame.mixer.music.stop()
        self.current_song = None